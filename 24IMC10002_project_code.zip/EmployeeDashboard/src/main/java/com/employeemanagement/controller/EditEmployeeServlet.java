/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// EditEmployeeServlet.java
package com.employeemanagement.controller;

import com.employeemanagement.util.MongoDBConnection;
import com.mongodb.client.*;
import org.bson.Document;
import org.bson.types.ObjectId;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class EditEmployeeServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String position = request.getParameter("position");
        String residence = request.getParameter("residence");

        double salary;
        try {
            salary = Double.parseDouble(request.getParameter("salary"));
        } catch (NumberFormatException e) {
            response.sendRedirect("editEmployee.jsp?id=" + id + "&message=Invalid+salary+input");
            return;
        }

        // Validate ID length and format BEFORE attempting to create ObjectId
        if (id == null || id.length() != 24 || !isValidHexString(id)) {
            response.sendRedirect("displayEmployee.jsp?message=Invalid+Employee+ID+format");
            return;
        }

        try {
            ObjectId objectId = new ObjectId(id);

            MongoDatabase database = MongoDBConnection.getDatabase();
            MongoCollection<Document> collection = database.getCollection("employees");

            Document update = new Document("$set", new Document("name", name)
                    .append("position", position)
                    .append("salary", salary)
                    .append("residence", residence));

            collection.updateOne(new Document("_id", objectId), update);

            response.sendRedirect("displayEmployee.jsp?message=Employee+updated+successfully");

        } catch (IllegalArgumentException e) {
            // This handles cases where the string is 24 characters but not a valid hex string
            response.sendRedirect("displayEmployee.jsp?message=Invalid+ObjectId+format");
        }
    }

    private boolean isValidHexString(String str) {
        if (str == null || str.length() != 24) {
            return false;
        }
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) {
                return false;
            }
        }
        return true;
    }
}